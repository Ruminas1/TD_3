#include <iostream>
#include <locale>
using namespace std;

class A {
public:
	// Tous les constructeurs de A initialisent x
	A() { // Constructeur sans param�tre (par d�faut)
		x = 0;
		cout << "A-1  Constructeur sans param�tre" << std::endl;
	}
	A(int px) { // Constructeur avec param�tre de type int
		x = px;
		cout << "A-2 Constructeur avec param�tre de type int" << std::endl;
	}
	A(const A& pa) { // Constructeur explicite de copie, il recoit un param�tre de type ref�rence constante � A
		x = pa.x;
		cout << "A-3 Constructeur de Copie" << std::endl;
	}
protected:
	int x;
};

class B {
public:
	// La classe B n'a pas de constructeur par d�faut explicite.

	//  Constructeur de B recoit un param�tre de type ref�rence constante � A
	//  et initialise a avec ce param�tre.
	//  Si le param�tre n'est pas fourni, il est initialis� avec un objet A par d�faut.
	B(const A& pa = A()) : a(pa) {
		cout << "B-4 Constructeur avec param�tre  de type ref�rence constante � A utilis� pour initialis� attribut 'a'" << std::endl;
	}

	// Constructeur de B recoit un param�tre de type ref�rence constante � A et un param�tre de type int
	B(const A& pa, int py) {
		a = pa;
		y = py;
		cout << "B-5 Constructeur avec param ref vers A et param int " << std::endl;
	}
protected:
	A a;
	int y{ 0 };
};

// La classe C h�rite de B
class C : public B {
public:
	C(int pz = 1) {
		z = pz;
		cout << "C-6 Construct param int" << std::endl;
	}
	C(A pa) : B(pa) {
		z = 0;
		cout << "C-7 Param classe A et appel du constructeur classe fille B avec le param classe A" << std::endl;
	}
	C(const B& pb) : B(pb), a(1) {
		z = 0;
		cout << "C-8 appel constructeur de copie par d�faut de la classe fille B et le constructeur de la classe A pour l'attribut 'a' " << std::endl;
	}
protected:
	A a;
	int z;
};

int main() {

	setlocale(LC_ALL, "fr_FR.UTF-8");

	cout << "-- A --\n";
	A a0; 		cout << endl;
	A a1(3); 		cout << endl;
	A a2(a1); 		cout << endl;
	A a3 = a2; 		cout << endl;
	a3 = a1; 		cout << endl;
	cout << "-- B --\n";
	B b0(a0, 3); 	cout << endl;
	B b1(a1); 		cout << endl;
	B b2; 		cout << endl;
	cout << "-- C --\n";
	C c0; 		cout << endl;
	C c1(a1); 		cout << endl;
	C c2(b2); 		cout << endl;
}