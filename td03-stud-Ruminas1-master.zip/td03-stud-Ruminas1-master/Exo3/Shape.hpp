#pragma once
#include <iostream>
#include <math.h>
#include "Point2D.hpp"

using namespace geometry;

enum class Color : unsigned char
{
    blue = 0,
    green = 1,
    orange = 2,
    brown = 3
};

class Shape
{
private :
    static unsigned global_count_;
    unsigned count_;
    const Color color;
public:
    Shape();
    Shape(const Color& color = Color::blue);
    Color color_;
    virtual float get_area() = 0;
    virtual void print_data() = 0;
    virtual ~Shape();
};

class Rectangle : Shape
{
protected :
    float length_;
    float width_;
public :
    float get_area();
    void print_data();
    Rectangle(const float& length, const float& width);
};

class Triangle : public Shape
{
private :
    float length_side1_;
    float length_side2_;
    float length_side3_;
    float get_area();
    void print_data();
public:
    Triangle(const float& length_side1, const float& length_side2,
        const float& length_side3);
    Triangle(const float& length_side1, const float& length_side2,
        const float& length_side3, Color color);
};

class Circle : Shape
{
private:
    float radius_;
public:
    float get_area();
    virtual void print_data();
    Circle(const float& radius);
};

class Square : Rectangle
{
    void print_data();
    Square(const float& length);
};