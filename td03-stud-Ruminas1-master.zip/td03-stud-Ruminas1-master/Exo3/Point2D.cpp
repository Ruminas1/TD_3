#include "Point2D.hpp"
#include "MyRand.hpp"
#include <iostream>

geometry::Point2D::Point2D()
{
	/*x = static_cast<float>(Random::get(1, 100));
	y = static_cast<float>(Random::get(1, 100));*/
	x = 0;
	y = 0;
}

geometry::Point2D::Point2D(const float& newx, const float& newy)
{
	x = newx;
	y = newy;
}

void geometry::Point2D::setXY(const float& newx, const float& newy)
{
	x = newx;
	y = newy;
}

void geometry::Point2D::setX(const float& newx)
{
	x = newx;
}

void geometry::Point2D::setY(const float& newy)
{
	y = newy;
}

float geometry::Point2D::getX() const
{
	return x;
}

float geometry::Point2D::getY() const
{
	return y;
}

void geometry::Point2D::print()
{
	std::cout << "x: " << x << " y: " << y << std::endl;
}

float geometry::Point2D::distanceTo(const Point2D& otherPoint2D)
{
	float distance = static_cast<float>(sqrt(pow(otherPoint2D.x - x, 2) + pow(otherPoint2D.y - y, 2)));
	return distance;
}

geometry::Point2D& geometry::Point2D::origin()
{
	return s_origin2D;
}


