
#include <iostream>
#include "Shape.hpp"


int main() {
	Shape* shapes[3];
	shapes[0] = new Rectangle(2, 3);
	shapes[1] = new Triangle(3, 4, 5);
	shapes[2] = new Circle(5);
	for (int i = 0; i < 3; i++) {
		shapes[i]->print_data();
	}
	for (int i = 0; i < 3; i++) {
		delete shapes[i];
	}
	return 0;

}