#include "Shape.hpp"
#include <math.h>
#include <iostream>

float Triangle::get_area() {
	float s = (length_side1_ + length_side2_ + length_side3_) / 2.0F;
	return sqrtf(s * (s - length_side1_) * (s - length_side2_) * (s - length_side3_));
}

void Triangle::print_data() {
	std::cout << "Triangle with sides " << length_side1_ << ", " << length_side2_ << ", " << length_side3_ << " has area " << get_area() << std::endl;
}

Triangle::Triangle(const float& length_side1, const float& length_side2, const float& length_side3) 
{
	length_side1_ = length_side1;
	length_side2_ = length_side2;
	length_side3_ = length_side3;
}
Triangle::Triangle(const float& length_side1, const float& length_side2, const float& length_side3, Color color) : Shape(color)
{
	length_side1_ = length_side1;
	length_side2_ = length_side2;
	length_side3_ = length_side3;
}

