#pragma once

namespace geometry
{
	class Point2D
	{
	protected:
		float x = 0, y = 0;   // private attributes

	public:
		// constuctors
		Point2D(); // fill X Y with random values (from 0 to 100)
		Point2D(const float& newx, const float& newy); // fill XY values

		// Setters and getters
		void setXY(const float& newx, const float& newy);
		void setX(const float& newx);
		void setY(const float& newy);
		float getX() const;
		float getY() const;

		// other methods
		void print();    // prints the coordinates of the point
		float distanceTo(const Point2D& otherPoint2D);

		static Point2D&
			origin(); // returns a point with coordinates (0,0)

		static Point2D s_origin;
	};

	static Point2D s_origin2D{ 0,0 };

} // namespace geometry