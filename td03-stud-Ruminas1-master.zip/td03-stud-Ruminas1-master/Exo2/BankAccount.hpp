#pragma once
#include <iostream>
#include <string>
#include <string_view>


class BankAccount {
private:
	const int number_ = 0;
	float balance_ = 0.0F;
	std::string owner_ = "";


public:

	BankAccount(const int &number, const float &initialBalance, std::string_view  owner);


	// ...



	float getBalance() const;


};

