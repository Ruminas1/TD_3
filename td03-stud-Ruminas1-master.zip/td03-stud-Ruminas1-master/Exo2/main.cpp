#include <iostream>

#include "BankAccount.hpp"
#include "SavingsAccount.hpp"
#include "CheckingAccount.hpp"


int main() {


	SavingsAccount savingsAccount(1, 1000.0F, "John Doe", 0.1F);
	CheckingAccount checkingAccount(2, 1000.0F, "Jane Doe", -500.0F);
	std::cout << "Savings account balance: " << savingsAccount.getBalance() << std::endl;
	std::cout << "Checking account balance: " << checkingAccount.getBalance() << std::endl;
	savingsAccount.depositAnnualInterest();
	checkingAccount.withdrawal(200.0F);
	std::cout << "Savings account balance: " << savingsAccount.getBalance() << std::endl;
	std::cout << "Checking account balance: " << checkingAccount.getBalance() << std::endl;
	checkingAccount.transfer(200.0F, savingsAccount);
	std::cout << "Savings account balance: " << savingsAccount.getBalance() << std::endl;
	std::cout << "Checking account balance: " << checkingAccount.getBalance() << std::endl;
	return 0;

}


