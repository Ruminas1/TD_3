#include "BankAccount.hpp"
#include <string_view>



BankAccount::BankAccount(const int & number, const float& initialBalance, std::string_view owner) : number_(number)
{
	balance_ = initialBalance;
	owner_ = owner;
}

// ...



float BankAccount::getBalance() const
{
	return balance_;
}
